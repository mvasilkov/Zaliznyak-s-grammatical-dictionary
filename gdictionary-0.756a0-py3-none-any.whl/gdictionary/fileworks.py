def read_decode(filename):
    """Read text from file,
    determine the encoding,
    decode the text.
    """
    
    '''
    charset = "utf-8"
    with open(filename, mode='rb') as infile:
        text = infile.read()
        if b'encoding="windows-1251"' in text:
            charset = "windows-1251"
    return text.decode(charset)
    '''
    
    try:
        with open(filename, mode='r', encoding='utf8') as infile:
            return infile.read()
    except UnicodeDecodeError:
        with open(filename, mode='r', encoding='cp1251') as infile:
            return infile.read()

