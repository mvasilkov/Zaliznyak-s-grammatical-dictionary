This is a module for predicting grammatical markers for unknown Russian words, according to notation from A.A. Zaliznyak's "Grammar Dictionary of the Russian Language". 


